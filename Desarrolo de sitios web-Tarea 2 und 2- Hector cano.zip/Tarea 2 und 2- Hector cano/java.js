function toggleMenu(opcion) {
  document.getElementById('mensajeBienvenida').classList.add('oculto');
  document.getElementById('formulario').classList.add('oculto');
  document.getElementById('saludarBtn').classList.add('oculto');

  if (opcion === 'bienvenida') {
      document.getElementById('mensajeBienvenida').classList.remove('oculto');
  } else if (opcion === 'formulario') {
      document.getElementById('formulario').classList.remove('oculto');
  }
}

function cerrarMensaje() {
  document.getElementById('mensajeBienvenida').classList.add('oculto');
}

function guardarDatos() {
  const nombre = document.getElementById('nombre').value;
  const apellido = document.getElementById('apellido').value;
  const correo = document.getElementById('correo').value;
  alert(`Datos guardados:\nNombre: ${nombre}\nApellido: ${apellido}\nCorreo: ${correo}`);
  document.getElementById('formulario').classList.add('oculto');
  document.getElementById('saludarBtn').classList.remove('oculto');
}

function saludar() {
  alert("¡Hola! Bienvenido a nuestra página web.");
}

// Array para almacenar los datos del formulario
var registros = [];

// Función para guardar los datos del formulario
function saveData() {
  var name = document.getElementById("name").value;
  var surname = document.getElementById("surname").value;
  var email = document.getElementById("email").value;

  // Crear un objeto con los datos del formulario
  var registro = {
    nombre: nombre,
    apellido: apellido,
    correo: email
  };

  // Agregar el registro al array
  registros.push(registro);

  // Mostrar los registros en la consola
  console.log(registros);

  // Limpiar los campos del formulario
  document.getElementById("name").value = "";
  document.getElementById("surname").value = "";
  document.getElementById("email").value = "";
}
